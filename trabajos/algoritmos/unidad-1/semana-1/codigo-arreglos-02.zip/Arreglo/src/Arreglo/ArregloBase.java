package Arreglo;

import java.util.Arrays;
import java.util.Scanner;

public abstract class ArregloBase {

    public static final Scanner TECLADO = new Scanner(System.in);

    private int[] numerito;
    private int tope;

    public ArregloBase() {
        this.numerito = null;
        this.tope = 0;
    }

    public ArregloBase(int valor) {
        if (valor < 1) {
            throw new IllegalArgumentException("El tamano debe ser mayor que 0.");
        }
        this.numerito = new int[valor];
        this.tope = 0;
    }

    // Constructor copia (lo usan las clases hijas)
    protected ArregloBase(ArregloBase otro) {
        if (otro.numerito == null) {
            this.numerito = null;
            this.tope = 0;
        } else {
            this.numerito = Arrays.copyOf(otro.numerito, otro.numerito.length);
            this.tope = otro.tope;
        }
    }

    // ---------- Getters y Setters (ENCAPSULAMIENTO) ----------
    public int[] getNumerito() {
        return numerito;
    }

    public void setNumerito(int[] numerito) {
        this.numerito = numerito;
    }

    public int getTope() {
        return tope;
    }

    public void setTope(int tope) {
        int capacidad = (numerito == null) ? 0 : numerito.length;
        if (tope < 0 || tope > capacidad) {
            throw new IllegalArgumentException("Tope fuera de rango: " + tope);
        }
        this.tope = tope;
    }

    public int getCapacidad() {
        return (numerito == null) ? 0 : numerito.length;
    }

    // Metodo para crear el arreglo
    public void creaArreglo(int valor) {
        if (valor < 1) {
            throw new IllegalArgumentException("El tamano debe ser mayor que 0.");
        }
        setNumerito(new int[valor]);
        setTope(0);
    }

    // ---------- Metodos de consulta ----------
    public boolean estaCreado() {
        return numerito != null;
    }

    public boolean tieneDatos() {
        return numerito != null && tope > 0;
    }

    public boolean estaLleno() {
        return numerito != null && tope == numerito.length;
    }

    /** Devuelve la posicion (0..tope-1) de la primera aparicion de x, o -1. */
    protected int buscar(int x) {
        for (int i = 0; i < tope; i++) {
            if (numerito[i] == x) {
                return i;
            }
        }
        return -1;
    }

    // ---------- Verificaciones que informan al usuario ----------
    public boolean verificaCreado() {
        if (!estaCreado()) {
            System.out.println(">> Primero debe crear el arreglo de practicas (opcion 2).");
            return false;
        }
        return true;
    }

    public boolean verificaConDatos() {
        if (!verificaCreado()) {
            return false;
        }
        if (tope == 0) {
            System.out.println(">> El arreglo no tiene elementos registrados.");
            return false;
        }
        return true;
    }

    public boolean verificaConEspacio() {
        if (!verificaCreado()) {
            return false;
        }
        if (estaLleno()) {
            System.out.println(">> El arreglo esta lleno, no se puede insertar.");
            return false;
        }
        return true;
    }

    public static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String linea = TECLADO.nextLine().trim();
            try {
                return Integer.parseInt(linea);
            } catch (NumberFormatException e) {
                System.out.println(">> Dato no valido: \"" + linea + "\". Ingrese un numero entero.");
            }
        }
    }

    /** Lee un entero y ademas valida que este dentro del rango [min, max]. */
    public static int leerEnteroEnRango(String mensaje, int min, int max) {
        while (true) {
            int valor = leerEntero(mensaje);
            if (valor >= min && valor <= max) {
                return valor;
            }
            System.out.println(">> Fuera de rango. El valor debe estar entre " + min + " y " + max + ".");
        }
    }

    /** Lee un texto no vacio. */
    public static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = TECLADO.nextLine().trim();
            if (!texto.isEmpty()) {
                return texto;
            }
            System.out.println(">> El dato no puede quedar vacio.");
        }
    }

    // ---------- Entrada de datos ----------
    /** Agrega un elemento al final del arreglo (usa getNumero, que es polimorfico). */
    public void lectura() {
        if (!verificaCreado()) {
            return;
        }
        if (getTope() < getCapacidad()) {
            getNumerito()[getTope()] = getNumero();
            setTope(getTope() + 1);
        } else {
            System.out.println(">> El arreglo esta lleno.");
        }
    }


    public int getNumero() {
        return leerEntero("Ingrese Numero : ");
    }

    // Metodo para mostrar datos (las hijas pueden sobrescribirlo)
    public void escritura() {
        System.out.println("\tListado");
        System.out.println("\t--------");

        if (!tieneDatos()) {
            System.out.println("No hay elementos");
        } else {
            for (int i = 0; i < getTope(); i++) {
                System.out.print(getNumerito()[i] + "\t");
            }
            System.out.println();
        }
    }

    /** Metodo abstracto: cada clase hija lo implementa a su manera. */
    public abstract void mostrarInformacion();
}
