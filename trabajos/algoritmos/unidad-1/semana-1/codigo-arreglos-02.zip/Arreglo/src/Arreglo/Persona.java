package Arreglo;

public abstract class Persona {

    private String nombres;
    private String apellidos;

    public Persona(String nombres, String apellidos) {
        setNombres(nombres);
        setApellidos(apellidos);
    }

    public String getNombres() {
        return nombres;
    }

    public final void setNombres(String nombres) {
        if (nombres == null || nombres.trim().isEmpty()) {
            throw new IllegalArgumentException("Los nombres no pueden estar vacios.");
        }
        this.nombres = nombres.trim();
    }

    public String getApellidos() {
        return apellidos;
    }

    public final void setApellidos(String apellidos) {
        if (apellidos == null || apellidos.trim().isEmpty()) {
            throw new IllegalArgumentException("Los apellidos no pueden estar vacios.");
        }
        this.apellidos = apellidos.trim();
    }

    public String getNombreCompleto() {
        return apellidos + ", " + nombres;
    }

    /** Cada tipo de persona dice que rol cumple. */
    public abstract String getRol();

    /** Cada tipo de persona se muestra a su manera (POLIMORFISMO). */
    public abstract void mostrarDatos();

    @Override
    public String toString() {
        return getRol() + ": " + getNombreCompleto();
    }
}
