package Arreglo;

import java.util.Locale;

public class ArregloEstadistico extends Arreglos implements Calculable {

    public ArregloEstadistico() {
        super();
    }

    public ArregloEstadistico(int valor) {
        super(valor);
    }

    private void exigeDatos() {
        if (!tieneDatos()) {
            throw new IllegalStateException("El arreglo no tiene elementos.");
        }
    }

    // 4. Sumar los elementos del arreglo
    @Override
    public int sumar() {
        exigeDatos();
        int suma = 0;
        for (int i = 0; i < getTope(); i++) {
            suma += getNumerito()[i];
        }
        return suma;
    }

    // 5a. Numero menor
    @Override
    public int hallarMenor() {
        exigeDatos();
        int menor = getNumerito()[0];
        for (int i = 1; i < getTope(); i++) {
            if (getNumerito()[i] < menor) {
                menor = getNumerito()[i];
            }
        }
        return menor;
    }

    // 5b. Numero mayor
    @Override
    public int hallarMayor() {
        exigeDatos();
        int mayor = getNumerito()[0];
        for (int i = 1; i < getTope(); i++) {
            if (getNumerito()[i] > mayor) {
                mayor = getNumerito()[i];
            }
        }
        return mayor;
    }

    // 5c. Promedio
    @Override
    public double hallarPromedio() {
        return (double) sumar() / getTope();
    }

    // 6. Suma de los elementos impares
    @Override
    public int sumarImpares() {
        exigeDatos();
        int suma = 0;
        for (int i = 0; i < getTope(); i++) {
            if (getNumerito()[i] % 2 != 0) {   // funciona tambien con negativos
                suma += getNumerito()[i];
            }
        }
        return suma;
    }

    // ---------- Metodos que muestran los resultados ----------
    public void mostrarSuma() {
        if (!verificaConDatos()) {
            return;
        }
        System.out.println("La suma de los elementos es: " + sumar());
    }

    public void mostrarEstadisticas() {
        if (!verificaConDatos()) {
            return;
        }
        System.out.println("Numero menor : " + hallarMenor());
        System.out.println("Numero mayor : " + hallarMayor());
        System.out.println("Promedio     : " + String.format(Locale.US, "%.2f", hallarPromedio()));
    }

    public void mostrarSumaImpares() {
        if (!verificaConDatos()) {
            return;
        }
        System.out.println("La suma de los elementos impares es: " + sumarImpares());
    }

    // POLIMORFISMO DINAMICO: sobrescribe el metodo de la clase padre
    @Override
    public void mostrarInformacion() {
        System.out.println("[ArregloEstadistico] Hereda de Arreglos y agrega: suma, menor, mayor, promedio y suma de impares.");
    }

    // POLIMORFISMO DINAMICO: amplia el listado heredado
    @Override
    public void escritura() {
        super.escritura();
        if (estaCreado()) {
            System.out.println("Elementos: " + getTope() + " de " + getNumerito().length);
        }
    }
}
