package Arreglo;

import java.util.Locale;


public class ArregloNotas extends ArregloEstadistico {

    // Reglas del negocio (constantes encapsuladas)
    public static final int NOTA_MINIMA = 0;
    public static final int NOTA_MAXIMA = 20;
    public static final int NOTA_APROBATORIA = 11;

    public ArregloNotas() {
        super();
    }

    public ArregloNotas(int cantidadPracticas) {
        super(cantidadPracticas);
    }

    @Override
    public int getNumero() {
        return leerEnteroEnRango("Nota de la Practica " + (getTope() + 1)
                + " (" + NOTA_MINIMA + "-" + NOTA_MAXIMA + ") : ",
                NOTA_MINIMA, NOTA_MAXIMA);
    }

    /** Ingresa todas las notas pendientes hasta llenar el arreglo. */
    public void ingresarNotas() {
        if (!verificaCreado()) {
            return;
        }
        if (estaLleno()) {
            System.out.println(">> Todas las notas ya fueron registradas.");
            return;
        }
        System.out.println("Ingreso de notas (faltan " + (getCapacidad() - getTope()) + "):");
        while (!estaLleno()) {
            lectura();
        }
        System.out.println(">> Notas registradas correctamente.");
    }

    // ---------- Calculos propios de la actividad ----------
    /** Posicion (0..tope-1) de la primera nota mas baja. */
    public int posicionMenor() {
        int pos = 0;
        for (int i = 1; i < getTope(); i++) {
            if (getNumerito()[i] < getNumerito()[pos]) {
                pos = i;
            }
        }
        return pos;
    }


    public double promedioSinMenor() {
        if (getTope() < 2) {
            throw new IllegalStateException("Se necesitan al menos 2 practicas para eliminar la nota mas baja.");
        }
        return (double) (sumar() - hallarMenor()) / (getTope() - 1);
    }

    /** Promedio final redondeado al entero mas cercano (0.5 sube). */
    public int promedioRedondeado() {
        return (int) Math.round(promedioSinMenor());
    }

    // POLIMORFISMO ESTATICO 
    public double promedioRedondeado(int decimales) {
        if (decimales < 0) {
            throw new IllegalArgumentException("Los decimales no pueden ser negativos.");
        }
        double factor = Math.pow(10, decimales);
        return Math.round(promedioSinMenor() * factor) / factor;
    }

    public boolean estaAprobado() {
        return promedioRedondeado() >= NOTA_APROBATORIA;
    }

    // ---------- Salidas por pantalla ----------
    /** Reporte completo del calculo pedido en la actividad. */
    public void mostrarPromedioPracticas() {
        if (!verificaConDatos()) {
            return;
        }
        if (getTope() < 2) {
            System.out.println(">> Se necesitan al menos 2 practicas para eliminar la nota mas baja.");
            return;
        }

        int menor = hallarMenor();
        int pos = posicionMenor();

        System.out.println("---------------------------------------------");
        System.out.println(" CALCULO DEL PROMEDIO DE PRACTICAS");
        System.out.println("---------------------------------------------");
        System.out.println("Practicas registradas : " + getTope());
        System.out.println("Suma de todas las notas: " + sumar());
        System.out.println("Nota mas baja eliminada: " + menor + "  (Practica " + (pos + 1) + ")");
        System.out.println("Suma sin la nota mas baja: " + (sumar() - menor));
        System.out.println("Practicas consideradas : " + (getTope() - 1));
        System.out.println("Promedio exacto        : "
                + String.format(Locale.US, "%.2f", promedioSinMenor()));
        System.out.println("PROMEDIO REDONDEADO    : " + promedioRedondeado());
        System.out.println("Condicion              : "
                + (estaAprobado() ? "APROBADO" : "DESAPROBADO"));
        System.out.println("---------------------------------------------");
    }

    // POLIMORFISMO DINAMICO: listado con formato de notas
    @Override
    public void escritura() {
        System.out.println("\tPRACTICA\tNOTA");
        System.out.println("\t--------\t----");
        if (!tieneDatos()) {
            System.out.println("\tNo hay notas registradas.");
            return;
        }
        for (int i = 0; i < getTope(); i++) {
            System.out.println("\tPractica " + (i + 1) + "\t" + getNumerito()[i]);
        }
        System.out.println("\tRegistradas: " + getTope() + " de " + getCapacidad());
    }

    // POLIMORFISMO DINAMICO: implementacion propia del metodo abstracto
    @Override
    public void mostrarInformacion() {
        System.out.println("[ArregloNotas] Arreglo de notas 0-20. Calcula el promedio "
                + "eliminando la nota mas baja y lo muestra redondeado.");
    }
}
