package Arreglo;


public interface Calculable {

    int sumar();

    int hallarMenor();

    int hallarMayor();

    double hallarPromedio();

    int sumarImpares();
}
