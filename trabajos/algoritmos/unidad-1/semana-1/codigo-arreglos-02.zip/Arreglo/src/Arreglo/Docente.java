package Arreglo;


public class Docente extends Persona {

    private String especialidad;

    public Docente(String nombres, String apellidos, String especialidad) {
        super(nombres, apellidos);
        setEspecialidad(especialidad);
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public final void setEspecialidad(String especialidad) {
        if (especialidad == null || especialidad.trim().isEmpty()) {
            throw new IllegalArgumentException("La especialidad no puede estar vacia.");
        }
        this.especialidad = especialidad.trim();
    }

    @Override
    public String getRol() {
        return "Docente";
    }

    // POLIMORFISMO DINAMICO
    @Override
    public void mostrarDatos() {
        System.out.println("Docente del curso : " + getNombreCompleto()
                + " | Especialidad: " + especialidad);
    }
}
