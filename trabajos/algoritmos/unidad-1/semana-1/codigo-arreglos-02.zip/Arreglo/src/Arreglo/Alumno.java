package Arreglo;

public class Alumno extends Persona {

    private String codigo;
    private String curso;
    private ArregloNotas practicas;

    public Alumno(String nombres, String apellidos, String codigo, String curso) {
        super(nombres, apellidos);
        setCodigo(codigo);
        setCurso(curso);
        this.practicas = new ArregloNotas();
    }

    public String getCodigo() {
        return codigo;
    }

    public final void setCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El codigo no puede estar vacio.");
        }
        this.codigo = codigo.trim();
    }

    public String getCurso() {
        return curso;
    }

    public final void setCurso(String curso) {
        if (curso == null || curso.trim().isEmpty()) {
            throw new IllegalArgumentException("El curso no puede estar vacio.");
        }
        this.curso = curso.trim();
    }

    public ArregloNotas getPracticas() {
        return practicas;
    }

    public void setPracticas(ArregloNotas practicas) {
        this.practicas = practicas;
    }

    /** Crea el arreglo donde se guardaran las notas de las practicas. */
    public void registrarCantidadPracticas(int cantidad) {
        if (cantidad < 2) {
            throw new IllegalArgumentException("Debe haber al menos 2 practicas para poder eliminar la mas baja.");
        }
        this.practicas = new ArregloNotas(cantidad);
    }

    @Override
    public String getRol() {
        return "Alumno";
    }

    // POLIMORFISMO DINAMICO
    @Override
    public void mostrarDatos() {
        System.out.println("=============================================");
        System.out.println(" FICHA DEL ALUMNO");
        System.out.println("=============================================");
        System.out.println("Alumno : " + getNombreCompleto());
        System.out.println("Codigo : " + codigo);
        System.out.println("Curso  : " + curso);
        System.out.println("---------------------------------------------");
        practicas.escritura();
        System.out.println("---------------------------------------------");
        if (practicas.tieneDatos() && practicas.getTope() >= 2) {
            System.out.println("Nota mas baja eliminada : " + practicas.hallarMenor());
            System.out.println("PROMEDIO REDONDEADO     : " + practicas.promedioRedondeado());
            System.out.println("Condicion               : "
                    + (practicas.estaAprobado() ? "APROBADO" : "DESAPROBADO"));
        } else {
            System.out.println("Aun no se puede calcular el promedio.");
        }
        System.out.println("=============================================");
    }
}
