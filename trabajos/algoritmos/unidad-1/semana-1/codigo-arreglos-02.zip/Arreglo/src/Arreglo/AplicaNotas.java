package Arreglo;

import java.util.Locale;


public class AplicaNotas {

    //(POLIMORFISMO)
    private static Alumno alumno = null;

    public static void main(String[] args) {
        System.out.println("*********************************************");
        System.out.println("   SISTEMA DE NOTAS DE PRACTICAS - JAVA POO   ");
        System.out.println("*********************************************");
        menu();
    }

    static void menu() {
        int opcion;

        do {
            System.out.println("         MENU DE OPCIONES");
            System.out.println("=============================================");
            System.out.println("1.- Registrar datos del alumno");
            System.out.println("2.- Registrar cantidad de practicas");
            System.out.println("3.- Ingresar notas de las practicas");
            System.out.println("=============================================");
            System.out.println("4.- Mostrar notas registradas");
            System.out.println("5.- Calcular promedio (sin la nota mas baja)");
            System.out.println("6.- Ficha completa del alumno");
            System.out.println("=============================================");
            System.out.println("7.- Demostracion de POO (herencia y polimorfismo)");
            System.out.println("0.- Salir");
            System.out.println("=============================================");

            opcion = ArregloBase.leerEnteroEnRango("Ingrese una alternativa (0-7) : ", 0, 7);
            System.out.println("");

            switch (opcion) {
                case 1 ->
                    registrarAlumno();
                case 2 ->
                    registrarPracticas();
                case 3 -> {
                    if (hayAlumno()) {
                        alumno.getPracticas().ingresarNotas();
                    }
                }
                case 4 -> {
                    if (hayAlumno()) {
                        alumno.getPracticas().escritura();
                    }
                }
                case 5 -> {
                    if (hayAlumno()) {
                        alumno.getPracticas().mostrarPromedioPracticas();
                    }
                }
                case 6 -> {
                    if (hayAlumno()) {
                        alumno.mostrarDatos();
                    }
                }
                case 7 ->
                    demostracionPOO();
                case 0 ->
                    System.out.println("Saliendo del sistema ....");
            }
            System.out.println("");

        } while (opcion != 0);
    }

    /** Verifica que exista un alumno antes de operar. */
    static boolean hayAlumno() {
        if (alumno == null) {
            System.out.println(">> Primero debe registrar los datos del alumno (opcion 1).");
            return false;
        }
        return true;
    }

    /** VALIDACION: ningun dato puede quedar vacio. */
    static void registrarAlumno() {
        String nombres = ArregloBase.leerTexto("Nombres del alumno   : ");
        String apellidos = ArregloBase.leerTexto("Apellidos del alumno : ");
        String codigo = ArregloBase.leerTexto("Codigo del alumno    : ");
        String curso = ArregloBase.leerTexto("Curso                : ");

        alumno = new Alumno(nombres, apellidos, codigo, curso);
        System.out.println(">> Alumno registrado: " + alumno.getNombreCompleto());
    }

    /** VALIDACION: minimo 2 practicas (se elimina una) y maximo 20. */
    static void registrarPracticas() {
        if (!hayAlumno()) {
            return;
        }
        int cantidad = ArregloBase.leerEnteroEnRango(
                "Cantidad de practicas del curso (2-20) : ", 2, 20);
        alumno.registrarCantidadPracticas(cantidad);
        System.out.println(">> Se creo el arreglo para " + cantidad + " practicas.");
    }

    /**
     * Demostracion de los 4 pilares de la POO en ejecucion.
     */
    static void demostracionPOO() {
        System.out.println("=============================================");
        System.out.println(" DEMOSTRACION DE PROGRAMACION ORIENTADA A OBJETOS");
        System.out.println("=============================================");

        // 1) POLIMORFISMO con la jerarquia Persona
        System.out.println("-- 1. Polimorfismo con Persona[] --");
        Docente docente = new Docente("Carlos", "Mendoza Rojas", "Algoritmica");
        Persona[] personas = (alumno == null)
                ? new Persona[]{docente}
                : new Persona[]{alumno, docente};

        for (Persona p : personas) {
            System.out.println("-> " + p);       // usa toString() sobrescrito
            p.mostrarDatos();                    // cada clase responde distinto
        }

        // 2) POLIMORFISMO con la jerarquia de arreglos
        System.out.println("-- 2. Polimorfismo con ArregloBase[] --");
        ArregloBase[] estructuras = (alumno == null)
                ? new ArregloBase[]{new Arreglos(), new ArregloEstadistico()}
                : new ArregloBase[]{new Arreglos(alumno.getPracticas()),
                    new ArregloEstadistico(), alumno.getPracticas()};

        for (ArregloBase a : estructuras) {
            a.mostrarInformacion();              // metodo abstracto implementado
        }

        // 3) POLIMORFISMO ESTATICO (sobrecarga de metodos)
        System.out.println("-- 3. Sobrecarga de metodos --");
        if (alumno != null && alumno.getPracticas().tieneDatos()
                && alumno.getPracticas().getTope() >= 2) {
            ArregloNotas n = alumno.getPracticas();
            System.out.println("promedioRedondeado()   -> " + n.promedioRedondeado());
            System.out.println("promedioRedondeado(2)  -> "
                    + String.format(Locale.US, "%.2f", n.promedioRedondeado(2)));
        } else {
            System.out.println("(Registre las notas para ver la sobrecarga en accion)");
        }

        // 4) ENCAPSULAMIENTO: el setter protege el objeto
        System.out.println("-- 4. Encapsulamiento (el setter rechaza datos invalidos) --");
        try {
            ArregloNotas prueba = new ArregloNotas(3);
            prueba.setTope(99);                  // 99 > capacidad 3
        } catch (IllegalArgumentException e) {
            System.out.println("Excepcion controlada: " + e.getMessage());
        }
        System.out.println("=============================================");
    }
}
