package clases;

/**
 * Clase CMatrix: representa una matriz cuadrada de numeros enteros y
 * todas las operaciones que se pueden realizar sobre ella.
 *
 * HERENCIA     : extends Matriz  -> reutiliza atributos y metodos base.
 * POLIMORFISMO : implements OperacionesMatriz -> cumple el contrato de las 10 actividades.
 *
 * @author Taipe Sulla Fernando
 */
public class CMatrix extends Matriz implements OperacionesMatriz {

    // ===== Constructores (SOBRECARGA) =====

    /** Constructor por defecto: matriz de tamano 0. */
    public CMatrix() {
        super();
    }

    /** Constructor sobrecargado: recibe el tamano y crea el arreglo. */
    public CMatrix(int tamano) {
        super(tamano);
    }

    /** Constructor de copia: crea una nueva matriz a partir de otra existente. */
    public CMatrix(int[][] matrizOriginal) {
        super(matrizOriginal);
    }

    // =====================================================================
    //  METODOS BASE (trabajo anterior)
    // =====================================================================

    public void leerNumero() {
        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                setElemento(i, j, leerEntero("Ingrese el elemento ["
                        + (i + 1) + "][" + (j + 1) + "] : "));
            }
        }
    }

    /** Implementacion OBLIGATORIA del metodo abstracto heredado de Matriz. */
    @Override
    public void escritura() {
        System.out.println("\tListado");
        System.out.println("\t===========");
        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                System.out.print(getElemento(i, j) + "\t");
            }
            System.out.println();
        }
    }

    public void sumaFila() {
        for (int i = 0; i < getTamano(); i++) {
            int sumaF = 0;
            for (int j = 0; j < getTamano(); j++) {
                sumaF += getElemento(i, j);
            }
            System.out.println("La suma de la fila " + (i + 1) + " es: " + sumaF);
        }
    }

    public void sumaColumna() {
        for (int j = 0; j < getTamano(); j++) {
            int sumaCol = 0;
            for (int i = 0; i < getTamano(); i++) {
                sumaCol += getElemento(i, j);
            }
            System.out.println("La suma de la columna " + (j + 1) + " es: " + sumaCol);
        }
    }

    public void sumaDiagonalMayor() {
        int aux = 0;
        for (int i = 0; i < getTamano(); i++) {
            aux += getElemento(i, i);
        }
        System.out.println("La suma de la diagonal mayor es: " + aux);
    }

    public void visualizarElemento() {
        int valorBuscado, posicion = 0, cont = 1, fila = 0, columna = 0;
        boolean encontrado = false;

        valorBuscado = leerEntero("Ingrese elemento a buscar: ");

        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                if (getElemento(i, j) == valorBuscado) {
                    posicion = cont;
                    fila = i;
                    columna = j;
                    encontrado = true;
                }
                cont++;
            }
        }

        if (encontrado) {
            System.out.println("El elemento se encuentra en la posicion " + posicion);
            System.out.println("El elemento se encuentra en la fila " + (fila + 1) + ", columna " + (columna + 1));
        } else {
            System.out.println("El elemento no se encuentra en la matriz");
        }
    }

    // =====================================================================
    //  ACTIVIDAD 1: Eliminar un elemento "x" de la matriz
    // =====================================================================
    /**
     * Elimina logicamente todas las apariciones del valor x.
     * En Java una matriz tiene tamano FIJO, por lo tanto no se puede quitar
     * una celda; la eliminacion se realiza asignando el valor neutro 0.
     *
     * @param x valor a eliminar
     * @return cantidad de elementos eliminados
     */
    @Override
    public int eliminarElemento(int x) {
        int contador = 0;
        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                if (getElemento(i, j) == x) {
                    setElemento(i, j, 0);
                    contador++;
                    System.out.println("Elemento " + x + " eliminado de la fila "
                            + (i + 1) + ", columna " + (j + 1));
                }
            }
        }
        if (contador == 0) {
            System.out.println("El elemento " + x + " no existe en la matriz.");
        } else {
            System.out.println("Total de elementos eliminados: " + contador);
        }
        return contador;
    }

    // =====================================================================
    //  ACTIVIDAD 2: Modificar un elemento "x" de la matriz
    // =====================================================================
    /**
     * Reemplaza todas las apariciones del valor x por un nuevo valor.
     *
     * @param x          valor actual que se desea cambiar
     * @param nuevoValor valor que se colocara en su lugar
     * @return cantidad de elementos modificados
     */
    @Override
    public int modificarElemento(int x, int nuevoValor) {
        int contador = 0;
        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                if (getElemento(i, j) == x) {
                    setElemento(i, j, nuevoValor);
                    contador++;
                    System.out.println("Fila " + (i + 1) + ", columna " + (j + 1)
                            + ": " + x + " -> " + nuevoValor);
                }
            }
        }
        if (contador == 0) {
            System.out.println("El elemento " + x + " no existe en la matriz.");
        } else {
            System.out.println("Total de elementos modificados: " + contador);
        }
        return contador;
    }

    // =====================================================================
    //  ACTIVIDAD 3: Sumar todos los elementos de la matriz
    // =====================================================================
    @Override
    public int sumarElementos() {
        int suma = 0;
        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                suma += getElemento(i, j);
            }
        }
        return suma;
    }

    /** Metodo de presentacion: muestra la suma total en pantalla. */
    public void visualizarSumaTotal() {
        System.out.println("La suma de todos los elementos de la matriz es: " + sumarElementos());
    }

    // =====================================================================
    //  ACTIVIDAD 4: Menor, mayor y promedio
    // =====================================================================
    @Override
    public int obtenerMenor() {
        int menor = getElemento(0, 0);
        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                if (getElemento(i, j) < menor) {
                    menor = getElemento(i, j);
                }
            }
        }
        return menor;
    }

    @Override
    public int obtenerMayor() {
        int mayor = getElemento(0, 0);
        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                if (getElemento(i, j) > mayor) {
                    mayor = getElemento(i, j);
                }
            }
        }
        return mayor;
    }

    @Override
    public double obtenerPromedio() {
        int cantidad = getTamano() * getTamano();
        return (double) sumarElementos() / cantidad;
    }

    @Override
    public void visualizarEstadisticas() {
        System.out.println("El numero MENOR de la matriz es : " + obtenerMenor());
        System.out.println("El numero MAYOR de la matriz es : " + obtenerMayor());
        System.out.printf("El PROMEDIO de la matriz es     : %.2f%n", obtenerPromedio());
    }

    // =====================================================================
    //  ACTIVIDAD 5: Suma de los extremos que forman la letra L
    // =====================================================================
    /**
     * Forma de la L (ejemplo 4x4):
     *   X . . .
     *   X . . .
     *   X . . .
     *   X X X X
     * Primera columna completa + ultima fila (sin repetir la esquina).
     */
    @Override
    public int sumaExtremosL() {
        int n = getTamano();
        int suma = 0;
        for (int i = 0; i < n; i++) {           // palo vertical: primera columna
            suma += getElemento(i, 0);
        }
        for (int j = 1; j < n; j++) {           // base horizontal: ultima fila
            suma += getElemento(n - 1, j);
        }
        return suma;
    }

    public void visualizarSumaL() {
        System.out.println("La suma de los elementos que forman la letra L es: " + sumaExtremosL());
    }

    // =====================================================================
    //  ACTIVIDAD 6: Suma de los extremos que forman la letra J
    // =====================================================================
    /**
     * Forma de la J (ejemplo 4x4):
     *   . . . X
     *   . . . X
     *   . . . X
     *   X X X X
     * Ultima columna completa + ultima fila (sin repetir la esquina).
     */
    @Override
    public int sumaExtremosJ() {
        int n = getTamano();
        int suma = 0;
        for (int i = 0; i < n; i++) {           // palo vertical: ultima columna
            suma += getElemento(i, n - 1);
        }
        for (int j = 0; j < n - 1; j++) {       // base horizontal: ultima fila
            suma += getElemento(n - 1, j);
        }
        return suma;
    }

    public void visualizarSumaJ() {
        System.out.println("La suma de los elementos que forman la letra J es: " + sumaExtremosJ());
    }

    // =====================================================================
    //  ACTIVIDAD 7: Suma de los extremos que forman la letra U
    // =====================================================================
    /**
     * Forma de la U (ejemplo 4x4):
     *   X . . X
     *   X . . X
     *   X . . X
     *   X X X X
     * Primera columna + ultima columna (sin la ultima fila) + ultima fila completa.
     */
    @Override
    public int sumaExtremosU() {
        int n = getTamano();
        int suma = 0;
        for (int i = 0; i < n - 1; i++) {       // palo izquierdo
            suma += getElemento(i, 0);
        }
        for (int i = 0; i < n - 1; i++) {       // palo derecho
            suma += getElemento(i, n - 1);
        }
        for (int j = 0; j < n; j++) {           // base de la U
            suma += getElemento(n - 1, j);
        }
        return suma;
    }

    public void visualizarSumaU() {
        System.out.println("La suma de los elementos que forman la letra U es: " + sumaExtremosU());
    }

    // =====================================================================
    //  ACTIVIDAD 8: Menor numero de cada fila
    // =====================================================================
    @Override
    public void visualizarMenorPorFila() {
        for (int i = 0; i < getTamano(); i++) {
            int menorFila = getElemento(i, 0);
            int columna = 0;
            for (int j = 1; j < getTamano(); j++) {
                if (getElemento(i, j) < menorFila) {
                    menorFila = getElemento(i, j);
                    columna = j;
                }
            }
            System.out.println("El menor numero de la fila " + (i + 1) + " es: "
                    + menorFila + "  (columna " + (columna + 1) + ")");
        }
    }

    // =====================================================================
    //  ACTIVIDAD 9: Contar los numeros pares de la matriz
    // =====================================================================
    @Override
    public int contarPares() {
        int contador = 0;
        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                if (getElemento(i, j) % 2 == 0) {
                    contador++;
                }
            }
        }
        return contador;
    }

    public void visualizarPares() {
        System.out.println("La cantidad de numeros PARES en la matriz es  : " + contarPares());
        System.out.println("La cantidad de numeros IMPARES en la matriz es: "
                + (getTamano() * getTamano() - contarPares()));
    }

    // =====================================================================
    //  ACTIVIDAD 10: Mover las filas una posicion a la derecha
    // =====================================================================
    /**
     * Desplaza cada fila una posicion a la derecha (rotacion circular):
     * el ultimo elemento de la fila pasa a ser el primero.
     */
    @Override
    public void rotarFilasDerecha() {
        int n = getTamano();
        for (int i = 0; i < n; i++) {
            int ultimo = getElemento(i, n - 1);      // 1) se guarda el ultimo
            for (int j = n - 1; j > 0; j--) {        // 2) se desplaza de derecha a izquierda
                setElemento(i, j, getElemento(i, j - 1));
            }
            setElemento(i, 0, ultimo);               // 3) el ultimo pasa al inicio
        }
        System.out.println("Filas desplazadas una posicion a la derecha.");
    }

    // =====================================================================
    //  UTILITARIO: carga una matriz de ejemplo (para pruebas / evidencias)
    // =====================================================================
    public void cargarEjemplo() {
        int[][] demo = {
            {8, 3, 12, 5},
            {7, 20, 1, 9},
            {4, 15, 6, 11},
            {2, 10, 14, 13}
        };
        setMatriz(demo);
        System.out.println("Matriz de ejemplo 4x4 cargada correctamente.");
    }

    // =====================================================================
    //  SOBRESCRITURA DE METODOS DE Object (POLIMORFISMO)
    // =====================================================================

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                sb.append(getElemento(i, j)).append("\t");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof CMatrix)) {
            return false;
        }
        CMatrix otra = (CMatrix) obj;
        if (this.getTamano() != otra.getTamano()) {
            return false;
        }
        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                if (this.getElemento(i, j) != otra.getElemento(i, j)) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + getTamano();
        for (int i = 0; i < getTamano(); i++) {
            for (int j = 0; j < getTamano(); j++) {
                hash = 31 * hash + getElemento(i, j);
            }
        }
        return hash;
    }
}
