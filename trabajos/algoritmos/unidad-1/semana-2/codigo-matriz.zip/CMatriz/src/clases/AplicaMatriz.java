package clases;

/**
 * Clase PRINCIPAL (capa de presentacion).
 * Solo se encarga de mostrar el menu y pedir datos al usuario;
 * toda la logica esta dentro del objeto CMatrix.
 *
 * Esto demuestra el principio de RESPONSABILIDAD UNICA de la POO.
 *
 * @author Taipe Sulla Fernando
 */
public class AplicaMatriz {

    // Instancia del objeto (constructor por defecto)
    static CMatrix objArreglo = new CMatrix();

    public static void main(String[] args) {
        menu();
    }

    static void menu() {
        int opcion, tam, x, nuevo;

        do {
            System.out.println("\n\n         MENU DE OPCIONES - MATRICES");
            System.out.println("=================================================");
            System.out.println("  CONFIGURACION");
            System.out.println("  1.- Crear el Arreglo (matriz n x n)");
            System.out.println("  2.- Ingresar Datos");
            System.out.println("  3.- Mostrar Datos");
            System.out.println("-------------------------------------------------");
            System.out.println("  OPERACIONES BASE");
            System.out.println("  4.- Sumar Filas");
            System.out.println("  5.- Sumar Columnas");
            System.out.println("  6.- Sumar Diagonal Mayor");
            System.out.println("  7.- Visualizar el contenido de una posicion");
            System.out.println("-------------------------------------------------");
            System.out.println("  ACTIVIDADES DESARROLLADAS");
            System.out.println("  8.- Eliminar un elemento X");
            System.out.println("  9.- Modificar un elemento X");
            System.out.println(" 10.- Sumar todos los elementos");
            System.out.println(" 11.- Menor, Mayor y Promedio");
            System.out.println(" 12.- Suma de extremos en forma de L");
            System.out.println(" 13.- Suma de extremos en forma de J");
            System.out.println(" 14.- Suma de extremos en forma de U");
            System.out.println(" 15.- Menor numero de cada fila");
            System.out.println(" 16.- Contar numeros pares");
            System.out.println(" 17.- Mover filas una posicion a la derecha");
            System.out.println("-------------------------------------------------");
            System.out.println(" 18.- Cargar matriz de ejemplo (4x4)");
            System.out.println("  0.- Salir");
            System.out.println("=================================================");

            opcion = Matriz.leerEntero("Ingrese una alternativa: ");
            System.out.println();

            switch (opcion) {
                case 1:
                    tam = Matriz.leerEntero("Ingrese tamano del Arreglo: ");
                    objArreglo.setTamano(tam);      // el setter crea el arreglo
                    System.out.println("Matriz de " + tam + " x " + tam + " creada.");
                    break;

                case 2:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.leerNumero();
                    }
                    break;

                case 3:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.escritura();
                    }
                    break;

                case 4:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.sumaFila();
                    }
                    break;

                case 5:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.sumaColumna();
                    }
                    break;

                case 6:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.sumaDiagonalMayor();
                    }
                    break;

                case 7:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.visualizarElemento();
                    }
                    break;

                // ===== ACTIVIDAD 1 =====
                case 8:
                    if (objArreglo.validarMatriz()) {
                        x = Matriz.leerEntero("Ingrese el elemento X a eliminar: ");
                        objArreglo.eliminarElemento(x);
                        System.out.println("\nMatriz resultante:");
                        objArreglo.escritura();
                    }
                    break;

                // ===== ACTIVIDAD 2 =====
                case 9:
                    if (objArreglo.validarMatriz()) {
                        x = Matriz.leerEntero("Ingrese el elemento X a modificar: ");
                        nuevo = Matriz.leerEntero("Ingrese el nuevo valor: ");
                        objArreglo.modificarElemento(x, nuevo);
                        System.out.println("\nMatriz resultante:");
                        objArreglo.escritura();
                    }
                    break;

                // ===== ACTIVIDAD 3 =====
                case 10:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.visualizarSumaTotal();
                    }
                    break;

                // ===== ACTIVIDAD 4 =====
                case 11:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.visualizarEstadisticas();
                    }
                    break;

                // ===== ACTIVIDAD 5 =====
                case 12:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.visualizarSumaL();
                    }
                    break;

                // ===== ACTIVIDAD 6 =====
                case 13:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.visualizarSumaJ();
                    }
                    break;

                // ===== ACTIVIDAD 7 =====
                case 14:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.visualizarSumaU();
                    }
                    break;

                // ===== ACTIVIDAD 8 =====
                case 15:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.visualizarMenorPorFila();
                    }
                    break;

                // ===== ACTIVIDAD 9 =====
                case 16:
                    if (objArreglo.validarMatriz()) {
                        objArreglo.visualizarPares();
                    }
                    break;

                // ===== ACTIVIDAD 10 =====
                case 17:
                    if (objArreglo.validarMatriz()) {
                        System.out.println("Matriz ORIGINAL:");
                        objArreglo.escritura();
                        objArreglo.rotarFilasDerecha();
                        System.out.println("\nMatriz DESPLAZADA:");
                        objArreglo.escritura();
                    }
                    break;

                case 18:
                    objArreglo.cargarEjemplo();
                    objArreglo.escritura();
                    break;

                case 0:
                    System.out.println("Gracias por usar el programa. Hasta pronto!");
                    break;

                default:
                    System.out.println("Opcion no valida, ingrese otra opcion.");
            }

        } while (opcion != 0);
    }
}
