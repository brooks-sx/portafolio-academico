package clases;

import java.util.Scanner;

/**
 * Clase ABSTRACTA que representa la estructura base de una matriz cuadrada.
 *
 * Pilares de POO aplicados:
 *  - ABSTRACCION    : define QUE hace una matriz (escritura) sin decir COMO.
 *  - ENCAPSULAMIENTO: los atributos son private y solo se acceden por get/set.
 *  - HERENCIA       : CMatrix hereda de esta clase (extends Matriz).
 *
 * @author Taipe Sulla Fernando
 */
public abstract class Matriz {

    // ===== Atributos privados (ENCAPSULAMIENTO) =====
    private int[][] matriz;
    private int tamano;

    /**
     * UNICO objeto Scanner de todo el programa.
     * Usar dos Scanner sobre System.in provoca perdida de datos y
     * excepciones en tiempo de ejecucion, por eso se comparte uno solo.
     */
    public static final Scanner TECLADO = new Scanner(System.in);

    /**
     * Lee un numero entero desde el teclado de forma segura.
     * Si el usuario escribe letras o deja la linea vacia, vuelve a preguntar
     * en lugar de lanzar InputMismatchException y cortar el programa.
     *
     * @param mensaje texto que se muestra al usuario
     * @return el numero entero ingresado
     */
    public static int leerEntero(String mensaje) {
        int valor = 0;
        boolean valido = false;
        while (!valido) {
            System.out.print(mensaje);
            try {
                valor = Integer.parseInt(TECLADO.nextLine().trim());
                valido = true;
            } catch (NumberFormatException e) {
                System.out.println(">> Dato no valido. Debe ingresar un numero entero.");
            }
        }
        return valor;
    }

    // ===== Constructores =====

    /** Constructor por defecto: matriz vacia de tamano 0. */
    public Matriz() {
        this.tamano = 0;
        this.matriz = new int[0][0];
    }

    /** Constructor sobrecargado: crea la matriz de n x n. */
    public Matriz(int tamano) {
        creaArreglo(tamano);
    }

    /** Constructor de copia: duplica el contenido de otra matriz ya existente. */
    public Matriz(int[][] matrizOriginal) {
        this.tamano = matrizOriginal.length;
        this.matriz = new int[tamano][tamano];
        for (int i = 0; i < tamano; i++) {
            System.arraycopy(matrizOriginal[i], 0, this.matriz[i], 0, tamano);
        }
    }

    // ===== Metodo ABSTRACTO (lo implementa obligatoriamente la subclase) =====

    /** Muestra el contenido de la matriz en pantalla. */
    public abstract void escritura();

    // ===== Getters y Setters =====

    public int[][] getMatriz() {
        return matriz;
    }

    public void setMatriz(int[][] matriz) {
        this.matriz = matriz;
        this.tamano = matriz.length;
    }

    public int getTamano() {
        return tamano;
    }

    public void setTamano(int tamano) {
        creaArreglo(tamano);
    }

    /** Getter de un elemento especifico de la matriz. */
    public int getElemento(int fila, int columna) {
        return matriz[fila][columna];
    }

    /** Setter de un elemento especifico de la matriz. */
    public void setElemento(int fila, int columna, int valor) {
        matriz[fila][columna] = valor;
    }

    // ===== Metodos de servicio comunes =====

    /** Reserva memoria para una matriz cuadrada de n x n. */
    public final void creaArreglo(int valor) {
        if (valor < 0) {
            valor = 0;
        }
        this.tamano = valor;
        this.matriz = new int[valor][valor];
    }

    /** Devuelve true si la matriz aun no ha sido creada. */
    public boolean estaVacia() {
        return tamano == 0;
    }

    /** Valida que la matriz exista antes de operar sobre ella. */
    public boolean validarMatriz() {
        if (estaVacia()) {
            System.out.println(">> ERROR: primero debe crear la matriz (opcion 1) e ingresar datos (opcion 2).");
            return false;
        }
        return true;
    }
}
