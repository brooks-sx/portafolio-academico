package clases;

/**
 * INTERFACE que define el CONTRATO de las 10 actividades solicitadas.
 *
 * Pilares de POO aplicados:
 *  - ABSTRACCION : declara las operaciones sin implementarlas.
 *  - POLIMORFISMO: cualquier clase que la implemente puede ser tratada
 *                  como un objeto de tipo OperacionesMatriz.
 *
 * @author Taipe Sulla Fernando
 */
public interface OperacionesMatriz {

    // Actividad 1
    int eliminarElemento(int x);

    // Actividad 2
    int modificarElemento(int x, int nuevoValor);

    // Actividad 3
    int sumarElementos();

    // Actividad 4
    int obtenerMenor();

    int obtenerMayor();

    double obtenerPromedio();

    void visualizarEstadisticas();

    // Actividad 5
    int sumaExtremosL();

    // Actividad 6
    int sumaExtremosJ();

    // Actividad 7
    int sumaExtremosU();

    // Actividad 8
    void visualizarMenorPorFila();

    // Actividad 9
    int contarPares();

    // Actividad 10
    void rotarFilasDerecha();
}
